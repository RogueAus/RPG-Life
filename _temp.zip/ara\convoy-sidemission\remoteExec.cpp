class mav_convoy_fnc_addTriggerHandlers {
    allowedTargets = 1;
};