/*
    File: ARA_master.cpp
    Author: Rogue
    Description: Functions for ARA Custom Content.
*/

class AusRebelArmy {
    tag = "ara";
    class functions {
        file = "ara\functions";
		class copOpener {};
		class autoSaveInv {};
    };
};

#include "convoy-sidemission\functions.cpp"