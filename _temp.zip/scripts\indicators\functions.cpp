class Maverick_Indicators {
	tag = "mav_indicator";
	class functions {
		file = "scripts\indicators";
		class getVehicleIndicatorOffsets {};
		class enableIndicator {};
		class disableIndicator {};
		class init { postInit = 1; };
	};
};