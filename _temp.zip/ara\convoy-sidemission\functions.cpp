class Maverick_Convoy {
	tag = "mav_convoy";
	class functions {
		file = "ara\convoy-sidemission";
		class init {postInit = 1;};
		class attackMe {};
		class startConvoy {};
		class move {};
		class follow {};
		class attack {};
		class dropLoot {};
		class createMarker {};
		class removal {};
		class addTriggerHandlers {};
		class giveUnitLoadout {};
		class checkUnit {};
		class followTrack {};
		class proximityCheck {};
		class addVehicleToChain {};
	};
};