class Cation_Crafting {
    tag = "cat_crafting";
    class functions {
        file = "ara\crafting";
        class craftAction {};
        class craft {};
        class craft_update {};
        class craft_updateFilter {};
        class levelCheck {};
    };
};